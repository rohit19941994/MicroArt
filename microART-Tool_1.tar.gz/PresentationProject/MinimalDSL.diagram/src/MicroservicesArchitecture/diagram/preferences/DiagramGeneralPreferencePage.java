/*
 * 
 */
package MicroservicesArchitecture.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(MicroservicesArchitecture.diagram.part.MicroservicesArchitectureDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
