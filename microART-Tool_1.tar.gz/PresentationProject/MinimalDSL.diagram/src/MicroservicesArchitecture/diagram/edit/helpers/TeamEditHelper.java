/*
 * 
 */
package MicroservicesArchitecture.diagram.edit.helpers;

/**
 * @generated
 */
public class TeamEditHelper
		extends MicroservicesArchitecture.diagram.edit.helpers.MicroservicesArchitectureBaseEditHelper {
}
