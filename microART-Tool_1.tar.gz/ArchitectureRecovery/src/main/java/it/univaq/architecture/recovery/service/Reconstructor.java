package it.univaq.architecture.recovery.service;

public interface Reconstructor {

}
